export interface PresignedUrlDto {
  fileName: string;
  contentType: string;
}
