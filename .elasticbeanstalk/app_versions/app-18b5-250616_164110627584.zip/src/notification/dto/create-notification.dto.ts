export class CreateNotificationDto {}
